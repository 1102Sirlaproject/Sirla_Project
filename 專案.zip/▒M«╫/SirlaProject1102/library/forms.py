from django import forms
from .models import library_library

class BookForm(forms.ModelForm):
    class Meta:
        model = library_library
        fields = '__all__'