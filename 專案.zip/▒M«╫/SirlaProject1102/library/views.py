from django.shortcuts import render, HttpResponseRedirect, get_object_or_404
from django.http import HttpResponse
from datetime import datetime
from .forms import BookForm
from .models import library

def hello_world(request):
    return render(request, 'hello.html',{
        'current_time': str(datetime.now())
        })

def book_list(request):
    Book_list = BookForm.objects.all()
    return render(request, 'book_list.html', {'Book_list': Book_list})

def book(request, book_id):
    book_information = BookForm.objects.filter(id=book_id).first()

    return render(request, 'book.html',{
        'book_information': book_information,
    })

def book_new(request):
    if request.method == "POST":
        form = BookForm(request.POST)
        if form.is_valid():
            library = form.save()
            return HttpResponseRedirect('/book/' + f'{library.id}')
    else:
        form = BookForm()
    return render(request, 'book_edit.html', {'form': form})

def book_edit(request, book_id):
    library = get_object_or_404(Books, id=book_id)
    if request.method == "POST":
        form = BookForm(request.POST, instance=library)
        if form.is_valid():
            library = form.save()
            return HttpResponseRedirect('/book/' + f'{library.id}')
    else:
        form = BookForm(instance=library) # instance 將尚未修改的原始資料填入
    return render(request, 'book_edit.html', {'form': form})
