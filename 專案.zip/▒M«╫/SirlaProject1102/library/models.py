from djongo import models

# Create your models here.
class library(models.Model):
    ISBN = models.CharField(verbose_name="分類編號",max_length=10)
    Title = models.CharField(verbose_name="書名",max_length=50)
    Author = models.CharField(verbose_name="作者",max_length=20)
    Chapter = models.CharField(verbose_name="章節",max_length=10)
    Abstract = models.CharField(verbose_name="簡述",max_length=200)
    Recommended = models.IntegerField(verbose_name="推薦指數")
    Comment = models.CharField(verbose_name="評論",max_length=100)
    Reference = models.CharField(verbose_name="參考資源",max_length=150)

    def __str__(self):
        return self.ISBN